from django.contrib import admin
from .models import ft,Booking

admin.site.register(ft)
admin.site.register(Booking)

# Register your models here.
