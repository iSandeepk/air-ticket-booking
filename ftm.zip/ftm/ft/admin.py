from django.contrib import admin
from .models import ft,Booking,UserProfile

admin.site.register(ft)
admin.site.register(Booking)
admin.site.register(UserProfile)

# Register your models here.
